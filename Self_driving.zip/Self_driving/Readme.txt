Hi there!

In this project you will be able to make a virtual car which can self-drive itself.

For this project you need this package to installed :
1. pygame (Link - https://pypi.org/project/pygame/)

After installing this through cmd(Command promplt). You are ready to go :)

Some map are provide in the file but you can create your own map using paint with size as (1200, 400)

Note - The colour of the road should be *white*

To put your map in the code:
1.Put your map in the folder of your program 
2.Open code and go to 4 line
3.There you will find track 
4.In that go in brackets () and type your your file name in this manner 'your map name' 

After that enjoy your virtual car riding on your map :)